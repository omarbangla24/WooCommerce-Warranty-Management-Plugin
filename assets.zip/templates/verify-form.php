<?php get_header(); ?>
<div class="wvs-verify" style="max-width:720px;margin:40px auto;padding:20px;border:1px solid #eee;border-radius:8px;">
  <h1>Warranty Verification</h1>
  <form method="get" action="<?php echo esc_url(home_url('/verify/')); ?>" style="display:flex;gap:10px;">
    <input type="text" name="wvs_code" placeholder="Enter Warranty Number" class="input" style="flex:1;padding:10px;">
    <button class="button" type="submit">Verify</button>
  </form>
  <?php if (!empty($_GET['wvs_code'])): ?>
    <?php $code = sanitize_text_field($_GET['wvs_code']); wp_redirect( home_url('/verify/'.urlencode($code)) ); exit; ?>
  <?php endif; ?>
  <p style="margin-top:10px;">Tip: Your warranty number looks like <code>WVS-YYYYMMDD-ORDER-RANDOM</code>.</p>
</div>
<?php get_footer(); ?>