<div class="wrap invoice-block">
  <div class="hdr" style="display:flex;align-items:center;justify-content:space-between;gap:16px;padding:16px 20px;border-bottom:1px solid #eee">
    <div style="display:flex;align-items:center;gap:12px;">
      <?php if (!empty($logo)): ?><img src="<?php echo esc_url($logo); ?>" alt="Logo" style="max-height:50px"><?php endif; ?>
      <div>
        <div style="font-size:18px;font-weight:700">Invoice</div>
        <div style="color:#666;font-size:12px"><?php echo $company ?: 'Company information is not set.'; ?></div>
      </div>
    </div>
    <div style="color:#666;font-size:12px">
      <div><strong>Warranty #:</strong> <?php echo esc_html($number); ?></div>
      <?php if (!empty($order_id)): ?><div><strong>Order #:</strong> <?php echo esc_html($order_id); ?></div><?php endif; ?>
      <?php if (!empty($order_date)): ?><div><strong>Date:</strong> <?php echo esc_html($order_date); ?></div><?php endif; ?>
    </div>
  </div>
  <div class="content" style="padding:18px">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div>
        <h4>Bill To</h4>
        <p style="margin:0"><?php echo esc_html($billing_name ?: 'Customer'); ?><br>
        <?php echo esc_html($billing_email ?: ''); ?><br><?php if (!empty($billing_phone)) echo esc_html($billing_phone); ?><br><?php if (!empty($billing_address)) echo esc_html($billing_address); ?></p>
      </div>
      <div>
        <h4>Payment</h4>
        <p style="margin:0"><strong>Total:</strong> <?php echo $total ?: ''; ?><br>
        <span style="color:#666;font-size:12px">Currency: <?php echo esc_html($currency ?: ''); ?></span></p>
      </div>
    </div>

    <table style="width:100%;border-collapse:collapse;margin-top:8px">
      <thead><tr><th style="text-align:left;border-bottom:1px solid #eee;padding:6px">Item</th><th style="text-align:left;border-bottom:1px solid #eee;padding:6px">Qty</th><th style="text-align:left;border-bottom:1px solid #eee;padding:6px">Unit</th></tr></thead>
      <tbody>
        <?php foreach($items as $it): ?>
          <tr style="<?php echo !empty($it['is_target']) ? 'background:#f9fffa;' : ''; ?>">
            <td style="padding:6px;border-bottom:1px solid #f3f3f3"><?php echo esc_html($it['name']); ?></td>
            <td style="padding:6px;border-bottom:1px solid #f3f3f3"><?php echo esc_html($it['qty']); ?></td>
            <td style="padding:6px;border-bottom:1px solid #f3f3f3"><?php echo $it['unit']; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <?php if (!empty($verify_url)): ?>
      <div style="display:flex;align-items:center;gap:10px;margin-top:8px">
        <img src="<?php echo esc_url('https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=' . rawurlencode($verify_url)); ?>" alt="QR" style="width:80px;height:80px">
        <div style="color:#666;font-size:12px">Scan to verify warranty: <?php echo esc_html($verify_url); ?></div>
      </div>
    <?php endif; ?>

    <?php $policy = get_option('wvs_policy_text'); if ($policy): ?>
      <div style="margin-top:8px;padding:8px;border:1px dashed #ddd;border-radius:6px;background:#fafafa">
        <strong>Warranty / Return Policy</strong>
        <div style="white-space:pre-wrap; margin-top:4px; font-size:12px;"><?php echo esc_html($policy); ?></div>
      </div>
    <?php endif; ?>
  </div>
</div>